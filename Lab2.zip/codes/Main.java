package pl.lublin.wsei.java.cwiczenia;

public class Main {

}
